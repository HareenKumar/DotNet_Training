﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace DataTypes
{
    internal class Program
    {


        /////////////////// Value Types //////////////////////

        //static void Square(int a, int b)
        //{
        //    a = a * a; // 25
        //    b = b * b; // 100
        //    Console.WriteLine(a + " " + b);
        //}
        //static void Main(string[] args)
        //{
        //    int num1 = 5;
        //    int num2 = 10;
        //    Console.WriteLine(num1 + " " + num2);
        //    test t1 = new test();
        //    int[] xyz = t1.checkvariablesI(num1, num2);
        //    Console.WriteLine(xyz[0].ToString() + " " + xyz[1].ToString());
        //    Console.ReadLine();
        //}


        //class test {
        //    public int[] checkvariablesI(int x, int y)
        //    {
        //        x = x * x;
        //        y = y * y;
        //        int[] z;
        //        z = new int[2];
        //        z[0] = x;
        //        z[1] = y;
        //        return z;
        //    }

        //}



        //////////////////////// Referencr Types ///////////////////////
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Person p1 = new Person();   
            Person p2 = new Person();
            p1.age = 5;
            p2.age = 10;

            Console.WriteLine(p1.age + " " + p2.age);
            Console.ReadLine();
        }

        static void RefTypes()
        {
           
            Person p1 = new Person();
        }

        class Person
        {
            public int age;
            public string name;

        }

    }
}
