﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Single dimensional Array
            //int[] arr1 = new int[5];
            //arr1[0] = 10;
            //arr1[1] = 20;
            //arr1[2] = 30;
            //arr1[3] = 40;
            //arr1[4] = 50;

            //for (int i = 0; i < arr1.Length; i++)
            //{
            //    Console.WriteLine(arr1[i]);
            //}

            // Console.WriteLine(arr1[2]);


            // Multi Dimenstional

            //int[,] multidimarr = new int[2, 3];
            //multidimarr[0, 0] = 10;
            //multidimarr[0, 1] = 20;
            //multidimarr[0, 2] = 30;

            //multidimarr[1, 0] = 40;
            //multidimarr[1, 1] = 50;
            //multidimarr[1, 2] = 60;

            //for (int i = 0; i < 2; i++)
            //{
            //    for (int j = 0; j < 3; j++)
            //    {
            //        Console.WriteLine(multidimarr[i, j];
            //    }
            //}


            // Jagged   Array or array of arrays

            //int[][] jagarr = new int[3][];
            //jagarr[0] = new int[3];
            //jagarr[1] = new int[2];
            //jagarr[2] = new int[4];


            //string[] arrstring = new string[5];
            //arrstring[0] = "White";
            //arrstring[1] = "blue";


            int[] numbersear = new int[10];
            numbersear[0] = 10;
            numbersear[1] = 20;
            numbersear[2] = 30;
            numbersear[3] = 40;
            numbersear[4] = 50;
            numbersear[5] = 60;
            numbersear[6] = 70;
            numbersear[7] = 80;
            numbersear[8] = 90;
            numbersear[9] = 100;

            // Console.WriteLine("Enter a Number");
            //int num = int.Parse(Console.ReadLine());
            //bool foundnum = false;
            //for (int i = 0; i < numbersear.Length; i++)
            //{
            //    //if (num == numbersear[i])
            //    //{
            //    //    foundnum = true;
            //    //    break;
            //    //}

            //    Console.WriteLine(numbersear[i]);
            //}

            //foreach (var item in numbersear)
            //{
            //    Console.WriteLine(item);
            //}
            //if (foundnum)
            //{
            //    Console.WriteLine("Number found");
            //}
            //else {
            //    Console.WriteLine("Number not found");
            //}

            // jagged arrays example
            int[][] jagarr = new int[3][];
            jagarr[0] = new int[2];
            jagarr[1] = new int[3];
            jagarr[2] = new int[4];

            jagarr[0][0] = 10;
            jagarr[0][1] = 20;

            jagarr[1][0] = 30;
            jagarr[1][1] = 40;
            jagarr[1][2] = 50;

            jagarr[2][0] = 111;
            jagarr[2][1] = 123;
            jagarr[2][2] = 666;
            jagarr[2][3] = 999;



            foreach (int[] array in jagarr)
            {
                foreach (var item in array)
                {
                    Console.WriteLine(item);
                }
            }





            //Console.WriteLine(multidimarr[1,1]);

            Console.ReadLine();
        }
    }
}
