﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructors
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  Program1 obj = new Program1();

            Program1 obj = new Program1();
            obj.DisplaynotStatic();

            Program1.Cacluculate(4);
            Program1.Display();
            string address =  Program1.address;

            Console.WriteLine("Address: " + address);
            

            //Program1.Display();
            //Program1.Cacluculate(8);

            Console.ReadLine();
        }
    }


   class Program1
    {
        static string name;
        static string Age;

        //public static string address;
        //static Program1()
        //{
        //    name = "Hareen";
        //    Age = "30";
        //    address = "3600 Apt 46, Fremont";
        //}

        //public Program1()
        //{
        //    Console.WriteLine("Not a Static Constructor");
        //}

       
        //public static void Display()
        //{
        //    //Console.WriteLine(name);
        //    //Console.WriteLine(Age);


        //    Console.WriteLine(Math.Sqrt(16));
        //    // Console.WriteLine(pro)
        //}

        //public static void Cacluculate(int a)
        //{
        //    int result = a * a;
        //    Console.WriteLine(result);
        //    //  return a;
        //}

        //public void DisplaynotStatic()
        //{
        //    Console.WriteLine("This is a non static Method");
        //}




    }
}
