﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControlStatements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // If condition
            //int i = int.Parse(Console.ReadLine());
            //if (i == 10)
            //{
            //    Console.WriteLine("The Matched Number is: " + i);
            //}
            //else if(i == 20)
            //{
            //    Console.WriteLine("The Matched Number is: " + i);
            //}
            //else if(i == 30)
            //{
            //    Console.WriteLine("The Matched Number is: " + i);
            //}
            //else
            //{
            //    Console.WriteLine("Number Not Matched");
            //}


            // Swith Case
            //char ch = char.Parse(Console.ReadLine());
            //string ch = Console.ReadLine();

            //switch (ch)
            //{
            //    case "a":
            //        Console.WriteLine("a is vowel");
            //        break;
            //    case "e":
            //        Console.WriteLine("e is vowel");
            //        break;
            //    case "i":
            //        Console.WriteLine("i is vowel");
            //        break;
            //    case "o":
            //        Console.WriteLine("o is vowel");
            //        break;
            //    case "u":
            //        Console.WriteLine("u is vowel");
            //        break;
            //    default: Console.WriteLine("Not a vowel");
            //        break;

            //}

            // For Loop
            //int k  = int.Parse(Console.ReadLine());

            //for (int i = 0; i <= k; i++)
            //{
            //    Console.WriteLine(i);
            //}

            //for (int i = 2; i <= 20; i++)
            //{
            //    for (int j = 2; j <= 10; j++)
            //    {
            //        Console.WriteLine("{0}*{1}={2}", i, j, j*i);
            //    }
            //}

            // While loop
            //int k  = int.Parse(Console.ReadLine());
            //int k = 1;
            //while (k <= 15)
            //{
            //    Console.WriteLine(k);
            //    k++;
            //}

            // Do while loop
            //int k = int.Parse(Console.ReadLine());
            //decimal factorial = 1;
            //do
            //{
            //    factorial = factorial * k;
            //    k--;
            //} while (k > 0);
            //Console.WriteLine($"The Factorial Number is: {factorial} ");




            Console.ReadLine();
        }
    }
}
