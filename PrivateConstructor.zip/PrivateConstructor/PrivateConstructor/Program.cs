﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Car obj = new Car("","");

            Car obj = Car.CreateInstance();
            obj.Display();
            Console.ReadLine();
        }
    }

    class Car
    {
        public string Name;
        public string Description;
        public string Model;


        private Car(string name, string model)
        {
            this.Name = name;
            this.Model = model;
        }

        public static string xCarier()
        {
            string result = "";
            return result;
        }
        public static Car CreateInstance()
        {
            return new Car("Ford", "2017");
        }
        public void Display()
        {
            Console.WriteLine("Car Name is: " + Name);
            Console.WriteLine("Car Model is: " + Model);
        }
    }
}
