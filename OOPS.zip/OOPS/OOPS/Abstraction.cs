﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS
{
    internal class Abstraction
    {
        static void main()
        {
            ExampleAbstraction obj = new ExampleAbstraction();
            obj.Result();
            Console.ReadLine();
        }
    }

    class ExampleAbstraction
    {
        int a = 10; int b = 20;



        public void Result()
        {
            Console.WriteLine("Print the values: " + a + " " + b);
        }
    }
}
