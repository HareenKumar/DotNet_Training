﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Classes and Objects
            //Student objstudent = new Student();
            //objstudent.Id = 1;
            //objstudent.Age = 20;
            //objstudent.Name = "Kumar";
            //objstudent.Class = "MPC";
            //objstudent.PrintTheValues();
            //Console.ReadLine();


            // Abstraction


            //ArrayList arl = new ArrayList();
            //arl.Add(10);
            //arl.Add(20);

            ExampleAbstraction obj = new ExampleAbstraction();
            obj.Result();
            Console.ReadLine();
        }
    }


    // Class and Objects Example
    //public class Student
    //{
    //    public int Id;
    //    public string Name;
    //    public int Age;
    //    public string Class;

    //    public void PrintTheValues()
    //    {
    //        Console.WriteLine( "Display Student Info: "  + Id + " " + Name + " " + Age + " " + Class);
    //    }


    //}


    // Abstraction

    class ExampleAbstraction
    {
        int a = 10; int b = 20;

        void Calculate()
        {
            Console.WriteLine("The Addition Value is: " + (a + b));
        }

        public void Result()
        {
            //Console.WriteLine("Print the values: " + a + " " + b);
            Calculate();
        }
    }
}
