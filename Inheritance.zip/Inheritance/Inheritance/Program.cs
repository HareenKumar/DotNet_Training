﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyClass3 obj = new MyClass3();
            obj.MyMethod1();
            obj.MyMethod2();
            obj.MyMethod3();
            
            

            Console.ReadLine();

        }
    }

    class MyClass1
    {
        int a;
        int c;
        public void MyMethod1()
        {
            Console.WriteLine("MyMethod1 from MyClass1");
        }
    }

    class MyClass2 : MyClass1
    {
        
        public void MyMethod2()
        {
            
            Console.WriteLine("MyMethod2 from MyClass2");
        }
    }

    class MyClass3 : MyClass2
    {
        public void MyMethod3()
        {
            Console.WriteLine("MyMethod3 from MyClass3");
        }
    }
}
