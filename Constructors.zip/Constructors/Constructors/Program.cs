﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructors
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Default Constructor
            //Car obj = new Car();
            //obj.DisplayCarDetaisl();

            // Parameterized Constructor
            //Car objpar = new Car("Suzuki", "Scross", 2019, "Blue");
            //objpar.DisplayCarDetaisl();

            //Car objpar1 = new Car("Toyota", "Fortuner", 2017, "White");
            //objpar1.DisplayCarDetaisl();

            // Copy Constructor

            //Car objcopy = new Car("Ford", "Eco Sporr", 2015, "Black");
            //Car objcopy1 = new Car(objcopy);
            //objcopy1.DisplayCarDetaisl();
            

            Console.ReadLine();

        }
    }

    class Car
    {
        public string Company;
        public string Model;
        public int year;
        public string color;

        // Default Constructor
        //public Car()
        //{
        //    this.Company = "Ford";
        //    this.Model = "Eco Sport";
        //    this.year = 2015;
        //    this.color = "Black";
        //}

        //public void DisplayCarDetaisl()
        //{
        //    Console.WriteLine("My Car Company is: " + Company);
        //    Console.WriteLine("My Car Model is: " + Model);
        //    Console.WriteLine("My Car Manufacture year is: " + year);
        //    Console.WriteLine("My Car Color is: " + color);
        //}


        // Parameterized Construcotr

        public Car(string a, string b, int c, string d)
        {
            this.Company = a;
            this.Model = b;
            this.year = c;
            this.color = d;
        }

        public void DisplayCarDetaisl()
        {
            Console.WriteLine("My Car Company is: " + Company);
            Console.WriteLine("My Car Model is: " + Model);
            Console.WriteLine("My Car Manufacture year is: " + year);
            Console.WriteLine("My Car Color is: " + color);
        }


        // Copy Constructor

        public Car(string a, string b, int c, string d)
        {
            this.Company = a;
            this.Model = b;
            this.year = c;
            this.color = d;
        }

        public Car(Car car)
        {
            Company = car.Company;
            Model = car.Model;
            year = car.year;
            color = car.color;
        }

        public void DisplayCarDetaisl()
        {
            Console.WriteLine("My Car Company is: " + Company);
            Console.WriteLine("My Car Model is: " + Model);
            Console.WriteLine("My Car Manufacture year is: " + year);
            Console.WriteLine("My Car Color is: " + color);
        }

    }
}
