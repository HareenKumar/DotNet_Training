﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{

    interface Interface1
    {
        void Method1();
        void Method2();
    }

    
    interface Ineterface2
    {
        void Method2();
    }

    class MyClass1 : Interface1, Ineterface2
    {
        public void Method1()
        {
            Console.WriteLine("This is from Interface");
        }


        void Interface1.Method2()
        {
            Console.WriteLine("This is from Interface1");
        }

        void Ineterface2.Method2()
        {
            Console.WriteLine("This is from Interface2");
        }
    }



    internal class Program
    {
        static void Main(string[] args)
        {
            MyClass1 myClass1 = new MyClass1();
            myClass1.Method1();
            Interface1 if1 = new MyClass1();
            if1.Method2();
            Ineterface2 if2 = new MyClass1();
            if2.Method2();
            Console.ReadLine();

        }
    }
}
