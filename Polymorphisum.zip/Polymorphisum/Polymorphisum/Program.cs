﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphisum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Method Overriding
            //Car objcar = new Car();
            //Bus objbus = new Bus();
            //Boat objboat = new Boat();

            //Vechicle[] vechicles = { objcar, objbus, objboat };

            //foreach (Vechicle vechicle in vechicles)
            //{
            //    vechicle.Go();
            //}

            // Method Overloading
            //exMethodOverloading obj = new exMethodOverloading();
            //obj.sum();
            //int x = obj.sum(2, 3);
            //int y = obj.sum(3, 4, 5);
            //int z = obj.sum(20, 30, 40, 50);

            //Console.WriteLine("X Value is: " + x + " Y value is: " + y + " Z value is: " + z);
            //Console.ReadLine();

            // Encapsulation

            Customer obj = new Customer();
            obj.CustomerCode = "1234";
            obj.CustomerName = "Hareen";
            obj.Add();
            
           
        }
    }


    // Method Overriding 
    //class Vechicle
    //{
    //    public virtual void Go()
    //    {

    //    }
    //}

    //class Car : Vechicle
    //{
    //    public override void Go()
    //    {
    //        Console.WriteLine("Car moves on the road");
    //    }
    //}

    //class Bus : Vechicle
    //{
    //    public override void Go()
    //    {
    //        Console.WriteLine("Bus moves on the road");
    //    }
    //}

    //class Boat : Vechicle
    //{
    //    public override void Go()
    //    {
    //        Console.WriteLine("Boat moves on the water");
    //    }
    //}


    // Method Overloading

    //public class exMethodOverloading
    //{
    //    public int sum(int a, int b)
    //    {
    //        return a + b;
    //    }

    //    public int sum(int a, int b, int c)
    //    {
    //        return sum(a + b, a + c);
    //    }

    //    public int sum(int a, int b, int c, int d)
    //    {
    //        return (a + b + c) + d;
    //    }

    //    public void sum()
    //    {
    //        Console.WriteLine("No Parameters");
    //    }
    //}

    //Encapsulation

    public class Customer
    {
        public string CustomerCode = "";
        public string CustomerName = "";
        public void Add()
        {
            validation();
            DbConnections();
        }

        private bool validation()
        {
            return false;
        }

        private bool DbConnections()
        {
            return false;
        }


    }
}
