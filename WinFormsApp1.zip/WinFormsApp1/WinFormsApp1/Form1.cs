namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                richTextBox1.Text = "";
                int num1 = int.Parse(textBox1.Text);
                int num2 = int.Parse(textBox2.Text);

                int result = num1 / num2;

                if (num1 < num2 )
                {
                    throw new Exception("Num1 is always greater than num2");
                }

                richTextBox1.Text = result.ToString();
            }
            catch (Exception ex)
            {

               // richTextBox1.Text = "Please Enter Numeric Values";
                richTextBox1.Text = ex.GetType() + " : " + ex.StackTrace +  " : " + ex.Message.ToString();

                //throw;
            }
            //finally
            //{
            //    label3.Text = "The Program Executed Successfully!";
            //}
            
        }
    }
}