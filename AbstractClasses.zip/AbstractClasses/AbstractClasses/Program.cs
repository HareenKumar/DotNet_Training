﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClasses
{

   abstract class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public abstract void Work();
        
    }

    class Student : Person
    {
        public override void Work()
        {
            Console.WriteLine("This is from Student Class");
        }

        public void Explnation()
        {

        }
    }

    class Employee : Person
    {
        public override void Work()
        {
            Console.WriteLine("This is from Employee Class");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person = new Student();
            person.Work();
            person = new Employee();
            person.Work();
            Console.ReadLine();
        }
    }
}
